Hugo + Decap CMS starter project for Replit + GitHub + Render.

Includes blog structure, SEO schema, internal links, and legal pages.
