---
title: "Welcome to the Blog"
date: 2025-04-20
description: "This is a demo blog post with SEO and internal linking support."
tags: ["demo", "hugo", "decap"]
categories: ["Getting Started"]
aliases: ["/welcome"]
schema: "Article"
---

Welcome to your first blog post. Here's a sample internal link to [the legal page](/legal/privacy/).
